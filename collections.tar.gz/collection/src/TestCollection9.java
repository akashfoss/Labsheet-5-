import java.util.HashSet;
import java.util.Iterator;


public class TestCollection9 {
	 public static void main(String args[]){
		 
		  HashSet<String> al=new HashSet();
		  al.add("Ravi");
		  al.add("Vijay");
		  al.add("Ravi");
		  al.add("Ajay");
		  Iterator<String> itr=al.iterator();
		  while(itr.hasNext()){
		   System.out.println(itr.next());
		  }
	 }

}
