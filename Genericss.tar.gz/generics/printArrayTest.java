package generics;

public class printArrayTest {
	public static void main(String[] args)
	{
		Integer[] i = { 1 , 2 , 3 , 4 , 5};
		PrintArray.printAnyArray(i);
		Double[] d = {1.1 , 2.2 , 3.3 , 4.4 };
		PrintArray.printAnyArray(d);
		String[] s = {"hai", "mounica","welcome", "to" ,"OOP"};
		PrintArray.printAnyArray(s);
		//Fraction[] f = { };
	}
}
