
public class BoxTest {
	 public static void main(String[] args) {
		 Box<Integer> integerBox = new Box<Integer>();
		 Box<String> stringBox = new Box<String>();
		 integerBox.set(new Integer(10));
		 stringBox.set(new String("Hello World"));
		 System.out.printf("Integer Value :%d\n", integerBox.get());
		 System.out.printf("String Value :%s\n", stringBox.get());
		 }
		 }
		 
		 
		 
		 
		 
		 
		 
	


