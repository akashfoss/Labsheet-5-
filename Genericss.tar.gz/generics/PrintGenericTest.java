package generics;

public class PrintGenericTest {
	public static void main( String [] args)
	{
		PrintGeneric.printAnyType(new Integer(10));
		PrintGeneric.printAnyType(new Float(10.5));
		PrintGeneric.printAnyType(new String("generics"));
		PrintGeneric.printAnyType(new Character('c'));
		PrintGeneric.printAnyType(new Fraction(2,3));
	}

}
